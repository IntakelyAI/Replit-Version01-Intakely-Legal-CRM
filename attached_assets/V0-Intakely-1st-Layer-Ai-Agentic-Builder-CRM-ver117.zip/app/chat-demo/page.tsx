import ChatDemoPage from "@/components/shared/chat-demo-page"

export default function ChatDemo() {
  return <ChatDemoPage />
}
