import FunctionsSettings from "@/components/agent-builder/settings/functions-settings"

export default function FunctionsSettingsPage() {
  return <FunctionsSettings />
}
