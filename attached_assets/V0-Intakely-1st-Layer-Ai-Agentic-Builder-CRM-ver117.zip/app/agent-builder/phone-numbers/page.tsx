import PhoneNumbersManager from "@/components/agent-builder/phone-numbers-manager"
import AgentBuilderLayout from "@/components/agent-builder/layout"

export default function PhoneNumbersPage() {
  return (
    <AgentBuilderLayout>
      <PhoneNumbersManager />
    </AgentBuilderLayout>
  )
}
