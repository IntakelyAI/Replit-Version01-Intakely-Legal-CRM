import ToolsManager from "@/components/agent-builder/tools-manager"

export default function ToolsPage() {
  return <ToolsManager />
}
