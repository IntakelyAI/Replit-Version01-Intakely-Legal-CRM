import CallHistoryManager from "@/components/agent-builder/call-history-manager"
import AgentBuilderLayout from "@/components/agent-builder/layout"

export default function CallHistoryPage() {
  return (
    <AgentBuilderLayout>
      <CallHistoryManager />
    </AgentBuilderLayout>
  )
}
