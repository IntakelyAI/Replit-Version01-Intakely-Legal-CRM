import BatchCallManager from "@/components/agent-builder/batch-call-manager"
import AgentBuilderLayout from "@/components/agent-builder/layout"

export default function BatchCallPage() {
  return (
    <AgentBuilderLayout>
      <BatchCallManager />
    </AgentBuilderLayout>
  )
}
