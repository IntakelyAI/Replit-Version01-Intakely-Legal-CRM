import KnowledgeBaseManager from "@/components/agent-builder/knowledge-base-manager"
import AgentBuilderLayout from "@/components/agent-builder/layout"

export default function KnowledgeBasePage() {
  return (
    <AgentBuilderLayout>
      <KnowledgeBaseManager />
    </AgentBuilderLayout>
  )
}
