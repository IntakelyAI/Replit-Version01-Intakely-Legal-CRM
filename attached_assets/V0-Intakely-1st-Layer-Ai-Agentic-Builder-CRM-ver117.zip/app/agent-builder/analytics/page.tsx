import AnalyticsManager from "@/components/agent-builder/analytics-manager"
import AgentBuilderLayout from "@/components/agent-builder/layout"

export default function AnalyticsPage() {
  return (
    <AgentBuilderLayout>
      <AnalyticsManager />
    </AgentBuilderLayout>
  )
}
