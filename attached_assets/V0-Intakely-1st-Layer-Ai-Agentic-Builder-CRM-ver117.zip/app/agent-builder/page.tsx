import AgentBuilderLayout from "@/components/agent-builder/layout"
import AgentList from "@/components/agent-builder/agent-list"

export default function AgentBuilderPage() {
  return (
    <AgentBuilderLayout>
      <AgentList />
    </AgentBuilderLayout>
  )
}
