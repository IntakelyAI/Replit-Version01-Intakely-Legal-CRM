import InternalLayout from "@/components/internal-operations/layout"

export default function InternalOperationsPage() {
  return (
    <InternalLayout>
      <div className="p-6">
        <h1 className="mb-6 text-2xl font-bold text-white">Internal Operations Dashboard</h1>
        <p className="text-gray-400">This is a placeholder for the Intakely Internal Operations CRM layer.</p>
      </div>
    </InternalLayout>
  )
}
